MOSSLIGHT — WEBSITE DEMONSTRATION PACKAGE

This archive exists only to demonstrate the download section of the Frokyte Games website.
It does not contain a playable game.

Title: Mosslight
Version: 1.0.0 (sample listing)
Status: Demonstration / placeholder

The artwork shown on the website is CC0 pixel art from SpritePilot's free game backgrounds collection.
Source: https://spritepilot.com/free-game-assets/backgrounds
License: CC0 1.0

No actual game executable is included.
